Taken from https://unpkg.com/textcomplete@0.14.2/dist/textcomplete.min.js
Project https://github.com/yuku-t/textcomplete/
