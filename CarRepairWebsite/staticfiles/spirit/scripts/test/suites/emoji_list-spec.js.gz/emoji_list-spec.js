(function() {
  describe("editor plugin tests", function() {
    return it("returns the emoji list", function() {
      return expect(stModules.emojiList[0]).toEqual("+1");
    });
  });

}).call(this);

//# sourceMappingURL=emoji_list-spec.js.map
